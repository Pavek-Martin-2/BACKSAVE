/*      HELLO.C -- Hello, world */

#include <stdio.h>

main() {
printf("Hello, world 2\n");
return(0);
}



