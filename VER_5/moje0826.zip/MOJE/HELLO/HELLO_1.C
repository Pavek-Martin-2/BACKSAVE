/*      HELLO.C -- Hello, world */

#include <stdio.h>

main() {
printf("Hello, world 1\n");
return(0);
}



