//#include <stdlib.h>
#include <stdio.h>

// prevod int -> string
// prevod long -> string

int main() {
    char text[32];
    int i = 1234;
    //long l = 123456789L;
    long l = 1234567891L; // max 10 cislic

    itoa(i, text, 10);  // Prevod int na string
    ltoa(l, text, 10);  // Prevod long na string

    printf("%d\n", i);
    printf("%lu\n", l);

    return 0;
}
