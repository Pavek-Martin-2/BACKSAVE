#include <dir.h>
#include <stdio.h>
#include <string.h>

int main() {
    //clear; ?

    int delka, delka_2;
    //str aa;
    char cesta[MAXPATH];

    if (getcwd(cesta, MAXPATH) == NULL) {
	return 1;
    }

    delka = strlen(cesta);
    //printf ("%d\n", delka);

    if (delka > 0 && cesta[delka - 1] != '\\') {
	strcat(cesta, "\\");
    }

    printf("%s\n", cesta);

    delka_2 = strlen(cesta);
    printf ("%d\n", delka_2);

    return 0;
}
