#include <dir.h>
#include <stdio.h>
#include <string.h>

int main() {

    int delka;
    //str aa;
    char cesta[MAXPATH];

    if (getcwd(cesta, MAXPATH) == NULL) {
        return 1;
    }

    delka = strlen(cesta);

    if (delka > 0 && cesta[delka - 1] != '\\') {
        strcat(cesta, "\\");
    }

    printf("%s\n", cesta);

    return 0;
}
