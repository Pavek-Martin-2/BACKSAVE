#include <stdio.h>
#include <dir.h>

int main() {
    char buffer[128];
    if (getcwd(buffer, sizeof(buffer)) != NULL) {
	printf("Aktualni adresar: %s\n", buffer);
	printf("%s\n", buffer);
    }
    return 0;
}

