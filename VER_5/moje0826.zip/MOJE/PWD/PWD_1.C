#include <stdio.h>
#include <dir.h>

int main() {
    char dir[64];
    getcurdir(0, dir);
    printf("Adresar (bez disku): \\%s\n", dir);
    return 0;
}
