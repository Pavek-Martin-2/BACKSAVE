#include <dir.h>
#include <stdio.h>
#include <string.h>
    int delka;
    //strings aa;

int main() {
    char cesta[MAXPATH];

    if (getcwd(cesta, MAXPATH) == NULL) {
	return 1;
    }

   //int delka = strlen(cesta);

    if (delka > 0 && cesta[delka - 1] != '\\') {
	strcat(cesta, "\\");
    }

    printf("Vysledna cesta: %s\n", cesta);

    return 0;
}




