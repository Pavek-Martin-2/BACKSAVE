#include <dir.h>
#include <stdio.h>
#include <string.h>

int main() {
    //clear; ?

    int delka, delka_2, delka_3;
    //str aa;
    char cesta[MAXPATH];
    char ss[] = "C:\\PROG\\BC31\\BIN\\";
    delka_3 = strlen(ss);

    //char ss[] = "abcd";

    if (getcwd(cesta, MAXPATH) == NULL) {
	return 1;
    }
    printf("cesta 1 = %s\n", cesta);
    delka = strlen(cesta);
    printf ("delka 1 = %d\n", delka);

    if (delka > 0 && cesta[delka - 1] != '\\') {
	strcat(cesta, "\\");
    }

    printf("cesta 2 = %s\n", cesta);

    delka_2 = strlen(cesta);
    printf ("delka 2 = %d\n", delka_2);

    printf ("ss = %s\n", ss);
    printf ("delka ss = %d\n", delka_3);

    printf ("porovnani cest\n"); // neni newline
    printf ("%s == %s\n", ss, cesta);


    if ( ss == cesta ) { // tady vyresit nefunkcni porovnani
    printf ("souhlasi\n");  // a tady dopise radek
    }else{
    printf ("NEsouhlasi\n");  // taky dopise radek a "\n"
    }


    return 0;
}
