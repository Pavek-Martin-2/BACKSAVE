#include <dir.h>
#include <stdio.h>
#include <string.h>

int main() {
    //clear; ?

    int delka, delka_2, delka_3;
    //string aa; //neslo
    char cesta[MAXPATH];
    char ss[] = "C:\\PROG\\BC31\\BIN\\";
    delka_3 = strlen(ss);
    //char ss[] = "abcd";

    if (getcwd(cesta, MAXPATH) == NULL) {
	return 1;
    }

    delka = strlen(cesta);
    printf ("delka = %d\n", delka);

    if (delka > 0 && cesta[delka - 1] != '\\') {
	strcat(cesta, "\\");
    }

    printf("cesta = %s\n", cesta);

    delka_2 = strlen(cesta);
    printf ("delka 2 = %d\n", delka_2);
    printf ("delka 3 = %d\n", delka_3);
    printf ("ss = %s\n", ss);

    if ( ss == cesta ) { // tady vyresit nefunkcni porovnani
    printf ("souhlasi");
    }else{
    printf ("NEsouhlasi");
    }



    return 0;
}
