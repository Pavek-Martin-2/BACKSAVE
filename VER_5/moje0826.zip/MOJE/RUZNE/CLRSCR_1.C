#include <stdio.h>
#include <conio.h>

// clrscr() getch()

void main()
{
        clrscr(); // maze obrazovku

	printf("cekam na stisk klavesy\n");
        getch(); // jako pause
}