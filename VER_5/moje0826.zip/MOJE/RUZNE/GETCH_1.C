#include <stdio.h>
#include <conio.h>

// clrscr() getch()

void main()
{
        clrscr(); // cls
	printf("smazal sem obrazovku - clrscr()\n");
	printf("a cekam na stisk klavesy - getch()");
	getch(); // ceka na stisk klavesy
}