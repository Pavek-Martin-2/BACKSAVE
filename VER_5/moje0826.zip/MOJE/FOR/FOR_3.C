#include <stdio.h>

int main() {
    unsigned long i; // 32-bitove cislo v 16-bitovem DOSu

    // smycka od 1 do 1 000 000 000
    for (i = 1; i <= 1000000000UL; i++) {
        printf("%lu\n", i); // %lu znamena unsigned long
    }

    return 0;
}
