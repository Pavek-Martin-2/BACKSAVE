/*	for_1.c     */
#include <stdio.h>

int aa;

main() {

for( aa = 0; aa <= 100; aa++ ){
/* printf( "%s\n", aa ); */
/*  for ( i=1; i<MAXWORDLEN; i++ ) */
    printf( "  %5d\n", aa );
/*  printf( "Greater %5d\n", overlencnt ); */
}
return(0);
}






	