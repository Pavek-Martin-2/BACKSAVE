#include <stdio.h>
//#include <string.h>
int a = 10;
int b = 20;

char c[] = "a";
char d[] = "b";

main() {
//printf("Hello, world\n");
printf("%d\n",a);
printf("%d\n",b);

if ( a == b ) {
printf ("souhlasi\n");
}else{
printf("nesouhlasi\n");
}

if ( c == d ) {
printf ("ano\n");
}else{
printf("ne\n");
}

// str aa = d[]; nevim  !

return(0);
}
