#include <stdio.h>
int a = 10;
int b = 20;

main() {
//printf("Hello, world\n");
printf("%d\n",a);
printf("%d\n",b);

if ( a == b ) {
printf ("souhlasi\n");
}else{
printf("NEsouhlasi\n");
}


return(0);
}



