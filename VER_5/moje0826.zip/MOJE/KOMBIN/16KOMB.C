/*      16kombin.c     */
#include <stdio.h>

int a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p;
unsigned int poc=32000;

main(){
for(a=0; a <= 1; a++){
for(b=0; b <= 1; b++){
for(c=0; c <= 1; c++){
for(d=0; d <= 1; d++){
for(e=0; e <= 1; e++){
for(f=0; f <= 1; f++){
for(g=0; g <= 1; g++){
for(h=0 ;h <= 1; h++){

for(i=0 ;i <= 1; i++){
for(j=0 ;j <= 1; j++){
for(k=0 ;k <= 1; k++){
for(l=0 ;l <= 1; l++){
for(m=0 ;m <= 1; m++){
for(n=0 ;n <= 1; n++){
for(o=0 ;o <= 1; o++){
for(p=0 ;p <= 1; p++){

/* printf( "  %5d\n", a ); */
/* printf( "%2d%2d%2d%2d%2d%2d%2d%2d%2d\n",poc,a,b,c,d,e,f,g,h); */
printf( "%2d%2d%2d%2d%2d%2d%2d%2d%2d%2d%2d%2d%2d%2d%2d%2d%2d\n",poc,a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p);
poc++;
/*  printf( "Greater %5d\n", overlencnt ); */
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
return(0);
}
