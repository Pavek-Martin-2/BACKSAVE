/*      8kombin.c     */
#include <stdio.h>

int poc,a,b,c,d,e,f,g,h;

main() {
for( a=0 ;a <= 1; a++ ){
for( b=0 ;b <= 1; b++ ){
for( c=0 ;c <= 1; c++ ){
for( d=0 ;d <= 1; d++ ){
for( e=0 ;e <= 1; e++ ){
for( f=0 ;f <= 1; f++ ){
for( g=0 ;g <= 1; g++ ){
for( h=0 ;h <= 1; h++ ){

/*    printf( "  %5d\n", a ); */
printf("%2d%2d%2d%2d%2d%2d%2d%2d%2d\n",poc,a,b,c,d,e,f,g,h);
poc++;
/*  printf( "Greater %5d\n", overlencnt ); */
}
}
}
}

}
}
}
}
return(0);
}




