#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys\stat.h>
#include <io.h>
#include <string.h>
#include <conio.h>

int prime(int n)
{
        int i;

        if (n % 2 == 0)
                return (n==2);
        if (n % 3 == 0)
                return (n==3);
        if (n % 5 == 0)
                return (n==5);
        for (i=7; i*i <= n; i+=2)
                if (n % i == 0)
                        return 0;
        return 1;
}


int main(void)
{
   int handle;
   char string[40];
   int length, res;
   // prime
	int i, n;
	n = 32200;
       //for ( i = 2; i <= n; i++ )
       //if (prime(i))
       //cprintf("%d\r\n", i);

   /*
    Create a file named "TEST.$$$" in the current directory and write
    a string to it.  If "TEST.$$$" already exists, it will be overwritten.
   */

   if ((handle = open("write_2.txt", O_WRONLY | O_CREAT | O_TRUNC,
                         S_IREAD | S_IWRITE)) == -1)
   {
      printf("Error opening file.\n");
      exit(1);
   }

 //strcpy(string, "Hello, world!\n");
	for ( i = 2; i <= n; i++ )
		if (prime(i))
		//ofstream(int, i);
		ofstream(int i, char*, int);
		//strcopy(string, "%d\n", i);
	      //cprintf("%d\r\n", i);

   length = strlen(string);

   if ((res = write(handle, string, length)) != length)
   {
      printf("Error writing to the file.\n");
      exit(1);
   }
   printf("Wrote %d bytes to the file.\n", res);

   close(handle);
   return 0;
}