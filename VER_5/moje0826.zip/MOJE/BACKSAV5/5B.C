#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dos.h>
#include <dir.h>
#include <time.h>

struct XX {
    char path[128];
    char mask[128];
};

int main(int argc, char *argv[]) {

    struct XX xx[50];
    int pocet = 0;

    char pwd[128];
    char sv[128] = "NONE";
    int nalezeno = 0;

    FILE *f;
    char line[256];
    char *strednik;
    int l;
    int i;

    struct date d;
    struct time t;

    char archiv[256];
    char cmd_fast[] = "config -set cpu cycles=20000";
    char cmd_slow[] = "config -set cpu cycles=auto";
    char cmd_arj[512];
    char cmd_test[512];

    /* -----------------------------
       ZISKANI CESTY K EXE SOUBORU
       ----------------------------- */
    char exe_path[128];
    char seznam_cesta[256];
    char *p;

    strcpy(exe_path, argv[0]);

    /* Najít poslední zpětné lomítko */
    p = strrchr(exe_path, '\\');
    if (p) {
        *(p + 1) = 0;   /* odříznout název EXE, ponechat lomítko */
    } else {
        /* EXE spuštěno bez cesty → použij aktuální adresář */
        getcwd(exe_path, sizeof(exe_path));
        strcat(exe_path, "\\");
    }

    /* Sestavit úplnou cestu k seznam.txt */
    sprintf(seznam_cesta, "%sseznam.txt", exe_path);

    /* -----------------------------
       NACIST SEZNAM Z EXTERNIHO SOUBORU
       ----------------------------- */
    f = fopen(seznam_cesta, "r");
    if (!f) {
        printf("Chyba: nelze otevrit %s\n", seznam_cesta);
        return 0;
    }

    while (!feof(f) && pocet < 50) {
        if (fgets(line, sizeof(line), f)) {
            strednik = strchr(line, ';');
            if (strednik) {
                *strednik = 0;
                strcpy(xx[pocet].path, line);
                strcpy(xx[pocet].mask, strednik + 1);

                /* odstranit \n */
                l = strlen(xx[pocet].mask);
                if (l > 0 && xx[pocet].mask[l-1] == '\n')
                    xx[pocet].mask[l-1] = 0;

                pocet++;
            }
        }
    }
    fclose(f);

    /* -----------------------------
       ZISKANI AKTUALNIHO ADRESARE
       ----------------------------- */
    getcwd(pwd, sizeof(pwd));
    if (strlen(pwd) != 3)
        strcat(pwd, "\\");

    printf("%s\n", pwd);

    /* -----------------------------
       NAJIT MASKU PRO AKTUALNI ADRESAR
       ----------------------------- */
    for (i = 0; i < pocet; i++) {
        if (strcmp(pwd, xx[i].path) == 0) {
            strcpy(sv, xx[i].mask);
            nalezeno = 1;
        }
    }

    printf("%d\n", nalezeno);

    if (!nalezeno) {
        printf("\nAdresar nenalezen v seznamu\n");
        return 0;
    }

    if (strcmp(sv, "NONE") == 0) {
        printf("\nAdresar v seznamu nalezen ale neni definovano\n");
        return 0;
    }

    printf("\n%s %s\n", pwd, sv);

    /* -----------------------------
       DATUM A CAS
       ----------------------------- */
    getdate(&d);
    gettime(&t);

    sprintf(archiv, "%s%02d%02d%02d%02d.arj",
            pwd,
            d.da_day,
            d.da_mon,
            d.da_year % 100,
            t.ti_hour);

    /* -----------------------------
       PRIKAZY
       ----------------------------- */
    sprintf(cmd_arj, "arj.exe a -r -m4 %s %s", archiv, sv);
    sprintf(cmd_test, "arj.exe t %s", archiv);

    /* -----------------------------
       SPUSTENI
       ----------------------------- */
    printf("%s\n", cmd_fast);
    system(cmd_fast);

    system("sleep.exe 10");

    printf("%s\n", cmd_arj);
    system(cmd_arj);

    system("sleep.exe 10");

    printf("%s\n", cmd_test);
    system(cmd_test);

    system("sleep.exe 10");

    printf("archiv je ve formatu DDMMYYHH.arj\n");

    printf("%s\n", cmd_slow);
    system(cmd_slow);

    system("sleep.exe 5");

    return 0;
}
