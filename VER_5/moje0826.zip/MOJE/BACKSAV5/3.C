#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dos.h>
#include <dir.h>
#include <time.h>

struct XX {
    char path[128];
    char mask[128];
};

int main() {
    struct XX xx[50];
    int pocet = 0;

    char pwd[128];
    char sv[128] = "NONE";
    int nalezeno = 0;

    /* 1. Nacteni seznamu z externiho souboru */
    FILE *f = fopen("seznam.txt", "r");
    if (!f) {
        printf("Chyba: nelze otevrit seznam.txt\n");
        return 0;
    }

    while (!feof(f) && pocet < 50) {
        char line[256];
        if (fgets(line, sizeof(line), f)) {
            char *strednik = strchr(line, ';');
            if (strednik) {
                *strednik = 0;
                strcpy(xx[pocet].path, line);
                strcpy(xx[pocet].mask, strednik + 1);

                /* odstranit \n */
                int l = strlen(xx[pocet].mask);
                if (l > 0 && xx[pocet].mask[l-1] == '\n')
                    xx[pocet].mask[l-1] = 0;

                pocet++;
            }
        }
    }
    fclose(f);

    /* 2. Ziskani aktualniho adresare */
    getcwd(pwd, sizeof(pwd));
    if (strlen(pwd) != 3)
        strcat(pwd, "\\");

    printf("%s\n", pwd);

    /* 3. Vyhledani adresare v nactenem seznamu */
    for (int i = 0; i < pocet; i++) {
        if (strcmp(pwd, xx[i].path) == 0) {
            strcpy(sv, xx[i].mask);
            nalezeno = 1;
        }
    }

    printf("%d\n", nalezeno);

    if (!nalezeno) {
        printf("\nAdresar nenalezen v seznamu\n");
        return 0;
    }

    if (strcmp(sv, "NONE") == 0) {
        printf("\nAdresar v seznamu nalezen ale neni definovano\n");
        return 0;
    }

    printf("\n%s %s\n", pwd, sv);

    /* 4. Datum a cas */
    struct date d;
    struct time t;
    getdate(&d);
    gettime(&t);

    char archiv[256];
    sprintf(archiv, "%s%02d%02d%02d%02d.arj",
            pwd,
            d.da_day,
            d.da_mon,
            d.da_year % 100,
            t.ti_hour);

    /* 5. Prikazy */
    char cmd_fast[] = "config -set cpu cycles=20000";
    char cmd_slow[] = "config -set cpu cycles=auto";

    char cmd_arj[512];
    sprintf(cmd_arj, "arj.exe a -r -m4 %s %s", archiv, sv);

    char cmd_test[512];
    sprintf(cmd_test, "arj.exe t %s", archiv);

    /* 6. Spousteni */
    printf("%s\n", cmd_fast);
    system(cmd_fast);

    system("sleep.exe 10");

    printf("%s\n", cmd_arj);
    system(cmd_arj);

    system("sleep.exe 10");

    printf("%s\n", cmd_test);
    system(cmd_test);

    system("sleep.exe 10");

    printf("archiv je ve formatu DDMMYYHH.arj\n");

    printf("%s\n", cmd_slow);
    system(cmd_slow);

    system("sleep.exe 5");

    return 0;
}
