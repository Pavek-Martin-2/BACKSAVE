#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dos.h>
#include <dir.h>
#include <time.h>

int main() {
    char pwd[128];
    char sv[128] = "NONE";
    int nalezeno = 0;

    /* 1. Získání aktuálního adresáře */
    getcwd(pwd, sizeof(pwd));

    /* Přidání zpětného lomítka pokud není kořen */
    if (strlen(pwd) != 3) {
        strcat(pwd, "\\");
    }

    printf("%s\n", pwd);

    /* 2. Tabulka adresářů a masek */
    char *AH[10] = {
        "C:\\HRY\\7DEN7NOC\\",
        "C:\\HRY\\ABUSE\\",
        "C:\\HRY\\ALADDIN\\",
        "C:\\HRY\\ALIENTRI\\",
        "C:\\HRY\\CLOVECE2\\",
        "C:\\HRY\\BERUSKY\\",
        "C:\\HRY\\BLOOD\\",
        "C:\\HRY\\CASTLEM\\",
        "C:\\HRY\\CASTLEM2\\",
        "C:\\HRY\\CC\\"
    };

    char *SC[10] = {
        "*.zal",
        "save*.spe",
        "NONE",
        "tril.sg?",
        "save",
        "NONE",
        "game????.sav",
        "?",
        "?",
        "savegame.??? conquer.ini"
    };

    /* 3. Vyhledání adresáře */
    for (int i = 0; i < 10; i++) {
        if (strcmp(pwd, AH[i]) == 0) {
            strcpy(sv, SC[i]);
            nalezeno = 1;
        }
    }

    printf("%d\n", nalezeno);

    if (!nalezeno) {
        printf("\nAdresar nenalezen v seznamu\n");
        return 0;
    }

    if (strcmp(sv, "NONE") == 0) {
        printf("\nAdresar v seznamu nalezen ale neni definovano\n");
        return 0;
    }

    printf("\n%s %s\n", pwd, sv);

    /* 4. Datum a čas */
    struct date d;
    struct time t;
    getdate(&d);
    gettime(&t);

    char archiv[256];
    sprintf(archiv, "%s%02d%02d%02d%02d.arj",
            pwd,
            d.da_day,
            d.da_mon,
            d.da_year % 100,
            t.ti_hour);

    /* 5. Sestavení příkazů */
    char cmd_fast[] = "config -set cpu cycles=20000";
    char cmd_slow[] = "config -set cpu cycles=auto";

    char cmd_arj[512];
    sprintf(cmd_arj, "arj.exe a -r -m4 %s %s", archiv, sv);

    char cmd_test[512];
    sprintf(cmd_test, "arj.exe t %s", archiv);

    /* 6. Spouštění externích programů */
    printf("%s\n", cmd_fast);
    system(cmd_fast);

    system("sleep.exe 10");

    printf("%s\n", cmd_arj);
    system(cmd_arj);

    system("sleep.exe 10");

    printf("%s\n", cmd_test);
    system(cmd_test);

    system("sleep.exe 10");

    printf("archiv je ve formatu DDMMYYHH.arj\n");

    printf("%s\n", cmd_slow);
    system(cmd_slow);

    system("sleep.exe 5");

    return 0;
}
